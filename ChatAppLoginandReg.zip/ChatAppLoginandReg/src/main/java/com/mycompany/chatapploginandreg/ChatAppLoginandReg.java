/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapploginandreg;

/**
 *
 * @author rohan
 */
import javax.swing.JOptionPane;

public class ChatAppLoginandReg {

    String userName;
    String userPassword;
    String userFirstName;
    String userLastName;
    String mobileNumber;
    String welcomeMessage;
    boolean isUsernameValid;
    boolean isPasswordValid;
    boolean isMobileValid;
    boolean isLoginSuccessful;

    public static void main(String[] args) {
        
        ChatAppLoginandReg app = new ChatAppLoginandReg();

        // Asking for the username
        String inputUsername = JOptionPane.showInputDialog("Enter a username:");
        
        app.validateUsername(inputUsername);

        // Asking for the password
        String inputPassword = JOptionPane.showInputDialog("Enter a password:");
        
        app.validatePassword(inputPassword);

        // Ask for the mobile number
        String inputMobile = JOptionPane.showInputDialog("Enter your phone number (+27 followed by 9 digits):");
        app.validateMobileNumber(inputMobile);

        // Registering user
        app.register();

        // Asking for the name and surname
        String inputFirstName = JOptionPane.showInputDialog("Enter your first name:");
        
        String inputLastName = JOptionPane.showInputDialog("Enter your last name:");

        // Login process
        app.login(inputFirstName, inputLastName);
        app.showLoginResult();
    }

    public boolean validateUsername(String input) {
        userName = input;
        
        if (userName.length() <= 5 && userName.contains("_")) {
            isUsernameValid = true;
        } else {
            isUsernameValid = false;
        }
        return isUsernameValid;
    }

    public boolean validatePassword(String input) {
        userPassword = input;
        
        // Check if password is 8+ characters, has uppercase, number, and special character
        if (userPassword.length() >= 8 && userPassword.matches("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()]).{8,}$")) {
            isPasswordValid = true;
            
        } else {
            isPasswordValid = false;
        }
        return isPasswordValid;
    }

    public boolean validateMobileNumber(String input) {
        if (input != null && input.startsWith("+27")) {
            
            String digits = input.substring(3);
            
            if (digits.matches("\\d{9}")) {
                isMobileValid = true;
                mobileNumber = input;
            } else {
                isMobileValid = false;
            }
        } else {
            isMobileValid = false;
        }
        return isMobileValid;
    }

    public String register() {
        if (isUsernameValid) {
            JOptionPane.showMessageDialog(null, "Username successfully captured");
            
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure it contains an underscore and is no more than 5 characters long");
        }

        if (isPasswordValid) {
            JOptionPane.showMessageDialog(null, "Password successfully captured");
            
        } else {
            JOptionPane.showMessageDialog(null, "Password must have at least 8 characters, a capital letter, a number, and a special character");
        }

        if (isMobileValid) {
            
            JOptionPane.showMessageDialog(null, "Mobile number successfully captured");
        } else {
            JOptionPane.showMessageDialog(null, "Mobile number must start with +27 and be followed by 9 digits");
        }

        return welcomeMessage;
    }

    public boolean login(String firstNameInput, String lastNameInput) {
        
        userFirstName = firstNameInput;
        userLastName = lastNameInput;

        if (userName == null || userPassword == null) {
            JOptionPane.showMessageDialog(null, "No account found. Please register first.");
            return false;
        }

        String loginUsername = JOptionPane.showInputDialog("Enter your username:");
        String loginPassword = JOptionPane.showInputDialog("Enter your password:");

        if (loginUsername.equals(userName) && loginPassword.equals(userPassword)) {
            isLoginSuccessful = true;
        } else {
            isLoginSuccessful = false;
        }

        return isLoginSuccessful;
    }

    public String showLoginResult() {
        
        if (isLoginSuccessful) {
            JOptionPane.showMessageDialog(null, "Login successful");
            
            welcomeMessage = "Welcome " + userFirstName + " " + userLastName + ", it's great to see you again.";
            JOptionPane.showMessageDialog(null, welcomeMessage);
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Incorrect username or password.");
        }
        return welcomeMessage;
    
    }
}
